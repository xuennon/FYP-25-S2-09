package com.example.wise_workout_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
